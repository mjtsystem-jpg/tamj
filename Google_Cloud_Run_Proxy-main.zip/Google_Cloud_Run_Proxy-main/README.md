# Google_Cloud_Run_Proxy

## Docker Image

```
docker.io/praveenkarunarathne/google-cloud-run-proxy
```

## Environment Variable Name

```
V2RAY_SERVER_IP
```
